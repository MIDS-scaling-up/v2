#ifndef OPENCV_OLD_CXMISC_H
#define OPENCV_OLD_CXMISC_H

#ifdef __cplusplus
#  include "opencv2/core/utility.hpp"
#endif

#endif
